
use App\Http\Controllers\LivroController;

Route::resource('livros', LivroController::class);
